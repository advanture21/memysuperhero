//Rabiatul Athirah Binti talib 20DDT20F1014
//Isabella Ak Minchan 20DDT20F1012
package mp1;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.ComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

public class Mp1 implements ActionListener{

    JFrame f;

    JPanel pnl_west, pnl_east;
    JPanel pnl_detail_form, pnl_search_form; 
    JPanel pnl_inbox1, pnl_inbox2, pnl_inbox3,pnl_inbox4, pnl_inbox5,pnl_inbox6, pnl_button;
    
    TitledBorder border_1, border_2, border_3;

    JLabel lbl_uid, lbl_name, lbl_size, lbl_color, lbl_quantity, lbl_vendor;
    JComboBox cbx_name, cbx_size, cbx_color;
    JTextField txt_uid,  txt_quantity, txt_vendor;
    JButton btn_insert, btn_update, btn_delete, btn_cancel;
    
    JLabel lbl_search;
    JTextField tf_search;
    JButton btn_search;
    
    JLabel lbl_specific;
    JComboBox cbx_choice;
    JButton btn_show;
    
    JTable table;
    
    JScrollPane sp;
    
    int CurrentDisplay = 0;
    
    String db_username = "root";
    String db_pwd = "";
    String db_url = "jdbc:mysql://localhost:3306/project_ipt_2022";
    Connection conn;
    ResultSet rs = null;
    
    Mp1(){
        f = new JFrame("Mini Project");
        
        //Start WEST
        pnl_search_form = new JPanel();
        pnl_search_form.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_search = new JLabel("ID: ");
        lbl_search.setPreferredSize(new Dimension(100, 20));
        tf_search = new JTextField(10);
        btn_search = new JButton("Fetch");
        btn_search.setPreferredSize(new Dimension(100, 20));
        btn_search.addActionListener(this);
        border_2 = BorderFactory.createTitledBorder("Fetch Material");
        pnl_search_form.add(lbl_search);
        pnl_search_form.add(tf_search);
        pnl_search_form.add(btn_search);
        pnl_search_form.setBorder(border_2);
        
        pnl_detail_form = new JPanel();
        pnl_detail_form.setLayout(new BoxLayout(pnl_detail_form, BoxLayout.Y_AXIS));

        pnl_inbox1 = new JPanel();
        pnl_inbox1.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_uid = new JLabel(" ID: ");
        lbl_uid.setPreferredSize(new Dimension(150, 20));
        txt_uid = new JTextField();
        txt_uid.setPreferredSize(new Dimension(150, 20));
        txt_uid.setEditable(false);
        pnl_inbox1.add(lbl_uid);
        pnl_inbox1.add(txt_uid);
        
        pnl_inbox2 = new JPanel();
        pnl_inbox2.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_name = new JLabel("Material Name: ");
        lbl_name.setPreferredSize(new Dimension(150, 20));
        String[] materialName = {" Choose ", "Ribbon", "Plain Bag"};
        cbx_name = new JComboBox(materialName);
        cbx_name.setPreferredSize(new Dimension(150, 20));
        pnl_inbox2.add(lbl_name);
        pnl_inbox2.add(cbx_name);
        
        pnl_inbox3 = new JPanel();
        pnl_inbox3.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_size = new JLabel("Material Size: ");
        lbl_size.setPreferredSize(new Dimension(150, 20));
        String[] materialSize = {" Choose ", "2ft x 50cm", "50cm x 50cm"};
        cbx_size = new JComboBox(materialSize);
        cbx_size.setPreferredSize(new Dimension(150, 20));
        pnl_inbox3.add(lbl_size);
        pnl_inbox3.add(cbx_size);
        
        pnl_inbox4 = new JPanel();
        pnl_inbox4.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_color = new JLabel("Material Color: ");
        lbl_color.setPreferredSize(new Dimension(150, 20));
        String[] materialColor = {" Choose ", "Rainbow", "Navy Blue"};
        cbx_color = new JComboBox(materialColor);
        cbx_color.setPreferredSize(new Dimension(150, 20));
        pnl_inbox4.add(lbl_color);
        pnl_inbox4.add(cbx_color);
        
        pnl_inbox5 = new JPanel();
        pnl_inbox5.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_quantity = new JLabel("Material Quantity: ");
        lbl_quantity.setPreferredSize(new Dimension(150, 20));
        txt_quantity = new JTextField();
        txt_quantity.setPreferredSize(new Dimension(150, 20));
        pnl_inbox5.add(lbl_quantity);
        pnl_inbox5.add(txt_quantity);
        
        pnl_inbox6 = new JPanel();
        pnl_inbox6.setLayout(new FlowLayout(FlowLayout.CENTER));
        lbl_vendor = new JLabel("Material Vendor: ");
        lbl_vendor.setPreferredSize(new Dimension(150, 20));
        txt_vendor = new JTextField();
        txt_vendor.setPreferredSize(new Dimension(150, 20));
        pnl_inbox6.add(lbl_vendor);
        pnl_inbox6.add(txt_vendor);
        
        pnl_button = new JPanel();
        pnl_button.setLayout(new FlowLayout(FlowLayout.CENTER));
        btn_insert = new JButton("Insert");
        btn_insert.addActionListener(this);
        btn_delete = new JButton("Delete");
        btn_delete.addActionListener(this);
        btn_update = new JButton("Update");
        btn_update.addActionListener(this);
        btn_cancel = new JButton("Cancel");
        btn_cancel.addActionListener(this);
        pnl_button.add(btn_insert);
        pnl_button.add(btn_delete);
        pnl_button.add(btn_update);
        pnl_button.add(btn_cancel);
        
        border_1 = BorderFactory.createTitledBorder("Material Details");
        
        pnl_detail_form.add(pnl_inbox1);
        pnl_detail_form.add(pnl_inbox2);
        pnl_detail_form.add(pnl_inbox3);
        pnl_detail_form.add(pnl_inbox4);
        pnl_detail_form.add(pnl_inbox5);
        pnl_detail_form.add(pnl_inbox6);
        pnl_detail_form.add(pnl_button);
        
        pnl_west = new JPanel();
        pnl_west.setLayout(new BoxLayout(pnl_west, BoxLayout.Y_AXIS));
        pnl_west.add(pnl_search_form);
        pnl_west.add(pnl_detail_form);
        // End WEST

        try{
            //Table
            table = new JTable();
            sp = new JScrollPane(table);
            sp.setPreferredSize(new Dimension(500, 200));
            sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
            draw_table();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(f, "Error: " + ex);
        }
        
        pnl_east = new JPanel();
        pnl_east.setLayout(new BoxLayout(pnl_east, BoxLayout.Y_AXIS));
      
        pnl_east.add(sp);
        border_3 = BorderFactory.createTitledBorder("List of Materials");
        pnl_east.setBorder(border_3);

        
        f.add(pnl_west, BorderLayout.WEST);
        f.add(pnl_east, BorderLayout.EAST);

        f.pack();
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
    
    public static void main(String[] args) {
        Mp1 app = new Mp1();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btn_insert){
           
            insert();
            
        }
        else if (e.getSource() == btn_update){
            update();
        }
        else if (e.getSource() == btn_delete){
            delete();
        }
        else if (e.getSource() == btn_cancel){
            display_insert();
            hide_delete_update();
            clear_form();
        }
        else if (e.getSource() == btn_search){
            search();
        }
        else if (e.getSource() == btn_show){
            CurrentDisplay = cbx_choice.getSelectedIndex();
            draw_table();
        }
    }
    
    public DefaultTableModel buildTableModel(ResultSet rs)
            throws SQLException {
        ResultSetMetaData metaData = rs.getMetaData();
        String[] column_title = {"UID","Name", "Size", "Color", "Quantity", "Vendor"};
        Vector<String> columnNames = new Vector<String>();
        columnNames.add("UID");
        columnNames.add("Name");
        columnNames.add("Size");
        columnNames.add("Color");
        columnNames.add("Quantity");
        columnNames.add("Vendor");
        
        int columnCount = metaData.getColumnCount();

         Vector<Vector<Object>> data = new Vector<Vector<Object>>();
        while (rs.next()) {
            Vector<Object> vector = new Vector<Object>();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                vector.add(rs.getObject(columnIndex));
            }
            data.add(vector);
        }

        return new DefaultTableModel(data, columnNames);

    }
    
    public void fetch_all() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(db_url, db_username, db_pwd);
            String sql;
            switch (CurrentDisplay){
                case 1:
                    sql = "SELECT * FROM materials WHERE material_name = 'Ribbon'";
                    break;
                case 2:
                    sql = "SELECT * FROM materials WHERE material_name = 'Plain Bag'";
                    break;
                case 3:
                    sql = "SELECT * FROM materials WHERE material_size = '2ft x 50cm'";
                    break;
                case 4:
                    sql = "SELECT * FROM materials WHERE material_size = '50cm x 50cm'";
                    break;
                case 5:
                    sql = "SELECT * FROM materials WHERE material_color = 'Rainbow'";
                    break;
                case 6:
                    sql = "SELECT * FROM materials WHERE material_color = 'Navy Blue'";
                    break;
                default:
                    sql = "SELECT * FROM materials";
            }
            
            PreparedStatement statement = conn.prepareStatement(sql);

            rs = statement.executeQuery();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex);
        }

    }
    
    public void draw_table() {
        try {
            fetch_all();
            table.setModel(buildTableModel(rs));
        } catch (Exception ex) {
            Logger.getLogger(Mp1.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void search() {
        //fetch single data
        if(validation_search()){
            int search;
        //set search var
        search = Integer.parseInt(tf_search.getText().toString());

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(db_url, db_username, db_pwd);
            String sql = "Select * from materials WHERE material_uid = ?";
            PreparedStatement statement = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            statement.setInt(1, search);
            //letakkan data dari database ke resultset
            rs = statement.executeQuery();

            //baca data dari result set dan set ke form
            if (rs.next()) {
                rs.beforeFirst();
                while (rs.next()) {
                    txt_uid.setText(rs.getString("material_uid"));
                    txt_quantity.setText(rs.getString("material_quantity"));
                    txt_vendor.setText(rs.getString("material_vendor"));
                    
                    if (rs.getString("material_name").equals("Ribbon")){
                        cbx_name.setSelectedIndex(1);
                    }
                    else{
                        cbx_name.setSelectedIndex(2);
                    }
                    
                    if (rs.getString("material_size").equals("2ft x 50cm")){
                        cbx_size.setSelectedIndex(1);
                    }
                    else{
                        cbx_size.setSelectedIndex(2);
                    }
                    
                    if (rs.getString("material_color").equals("Rainbow")){
                        cbx_color.setSelectedIndex(1);
                    }
                    else{
                        cbx_color.setSelectedIndex(2);
                    }
                }
                JOptionPane.showMessageDialog(f, "Succesfull!");
                display_delete_update();
                hide_insert();
            } else {
                JOptionPane.showMessageDialog(f, "No data has been insert with the ID!");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex);
        }
        }else{
             JOptionPane.showMessageDialog(f, "ID is Required!");
        }
    }
    
    public boolean validation_search(){
        if (tf_search.getText().toString().isEmpty()){
            return false;
        }
        else{
            return true;
        }
    }
    public void insert(){
        
        if (validation_form()){
            try {
            //loadkan variable
            Class.forName("com.mysql.cj.jdbc.Driver");

            //establish connection
            conn = DriverManager.getConnection(db_url, db_username, db_pwd);

            //database operation
            String sql_insert = "INSERT INTO materials(material_name, material_size, material_color, material_quantity, material_vendor) VALUES(?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql_insert);
            stmt.setString(1, cbx_name.getSelectedItem().toString());
            stmt.setString(2, cbx_size.getSelectedItem().toString());
            stmt.setString(3, cbx_color.getSelectedItem().toString());
            stmt.setInt(4, Integer.parseInt(txt_quantity.getText()));
            stmt.setString(5, txt_vendor.getText());
                
            int insert;
            insert = stmt.executeUpdate();
            
            
            if (insert > 0) {
                //success
                JOptionPane.showMessageDialog(f, "Inserted Successfully!");
                display_delete_update();
                clear_form();
                
            } else {
                //fail
                JOptionPane.showMessageDialog(f, "Insert Failed!");
                

            }
            draw_table();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex);

        }

       }else{
           JOptionPane.showMessageDialog(f, "Please completed the form!");
       }
    
    }
     
    public boolean validation_form(){
        boolean valid1 = ((cbx_name.getSelectedIndex()!=0) && (cbx_size.getSelectedIndex()!=0) && (cbx_color.getSelectedIndex()!=0));
        boolean valid2 = ((!txt_quantity.getText().toString().isEmpty()) && (!txt_vendor.getText().toString().isEmpty()));
        
        if (valid1 && valid2){
            return true;
        }
        else{
            return false;
        }
    }
    
    public void delete() {
       
        try {
            //loadkan variable
            Class.forName("com.mysql.cj.jdbc.Driver");

            //establish connection
            conn = DriverManager.getConnection(db_url, db_username, db_pwd);

            //database operation
            String sql = "DELETE FROM materials WHERE material_uid =?";
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setInt(1, Integer.parseInt(tf_search.getText()));

            int delete;
            delete = stmt.executeUpdate();

            if (delete > 0) {
                //success
                draw_table();
                clear_form();
                JOptionPane.showMessageDialog(f, "Successfully Delete!");

            } else {
                //fail
                JOptionPane.showMessageDialog(f, "Failed to Delete!");
            }

            } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex);
            }
        
        
    }
    
    public void clear_form() {
        cbx_name.setSelectedIndex(0);;
        cbx_size.setSelectedIndex(0);
        cbx_color.setSelectedIndex(0);;
        txt_quantity.setText("");
        txt_vendor.setText("");
        tf_search.setText("");
        txt_uid.setText("");
    }
    
    public void hide_delete_update() {
        btn_update.setVisible(false);
        btn_delete.setVisible(false);
        btn_cancel.setVisible(false);
        f.pack();
    }

    public void display_delete_update() {
        btn_update.setVisible(true);
        btn_delete.setVisible(true);
        btn_cancel.setVisible(true);
        f.pack();
    }

    public void hide_insert() {
        btn_insert.setVisible(false);
    }

    public void display_insert() {
        btn_insert.setVisible(true);
    }
    
     public void update(){
      if (validation_form()){
         try {
            //loadkan variable
            Class.forName("com.mysql.cj.jdbc.Driver");

            //establish connection
            conn = DriverManager.getConnection(db_url, db_username, db_pwd);

            //database operation
            String sql = "UPDATE materials SET material_name=?,  material_size=?,  material_color=?,  material_quantity=?, material_vendor=? WHERE material_uid =?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, cbx_name.getSelectedItem().toString());
            stmt.setString(2, cbx_size.getSelectedItem().toString());
            stmt.setString(3, cbx_color.getSelectedItem().toString());
            stmt.setInt(4, Integer.parseInt(txt_quantity.getText().toString()));
            stmt.setString(5, txt_vendor.getText().toString());
            stmt.setInt(6, Integer.parseInt(txt_uid.getText().toString()));
            

            int update;
            update = stmt.executeUpdate();

            if (update > 0) {
                //success
                draw_table();
                clear_form();
                JOptionPane.showMessageDialog(f, "Update Successfully!");

            } else {
                //fail
                JOptionPane.showMessageDialog(f, "Failed to Update!");

            }

          } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex);
          }  
         
         
        }else{
           JOptionPane.showMessageDialog(f, "Insert the data !!");
       }            
    }
}
